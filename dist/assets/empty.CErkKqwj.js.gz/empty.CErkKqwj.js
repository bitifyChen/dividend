import{_ as o,e as r,r as t,o as c}from"./index.CW6G0v0J.js";import"./__commonjsHelpers__.Cpj98o6Y.js";const n={};function s(_,a){const e=t("router-view");return c(),r(e)}const f=o(n,[["render",s]]);export{f as default};
//# sourceMappingURL=empty.CErkKqwj.js.map
